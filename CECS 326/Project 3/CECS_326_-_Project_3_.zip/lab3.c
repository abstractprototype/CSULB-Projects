//sorts list of numbers with two seperate threads
//sort both the sublists seperately
//merges the sorted list back together

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

#define SIZE 10
#define NUMBER_OF_THREADS 3

int list[SIZE] = {7, 12, 19, 3, 18, 4, 2, 6, 15, 8};

int sorted_list[SIZE]; //The third empty array for final sorted array

typedef struct{
    int *first;
    int *second;
}parameters;

void *sorter(void *params){ // 7 12 19 3 18
    //sort each sublist

    parameters *p = params;

    //begins sorting
    int begin = 0;
    int end = SIZE/2;
    for(int z = begin; z < end; z++){
        printf("The first given array is: %d\n", p->first[z]);
    }
    printf("\n");
    int i,j,t,k;
    for(i = begin; i < end; i++){
        for(j = begin; j < end-i-1; j++){
            if(p->first[j] > p->first[j+1]){
                t = p->first[j];
                p->first[j] = p->first[j+1];
                p->first[j+1] = t;
            }
        }
    }

    // int x;
    // for(x=begin; x<end; x++){
    //     sorted_list[x] = list[x];
    // }
    printf("\n");
    pthread_exit(0);
}

void *sorter2(void *params){ // 4 2 6 15 8
    //sort each sublist

    parameters *p = params;

    //begins sorting
    int begin = 0;
    int end = SIZE / 2;
    for(int z = begin; z < end; z++){
        printf("The second given array is: %d\n", p->second[z]);
    }
    printf("\n");
    int i,j,t,k;
    for(i = begin; i < end; i++){
        for(j = begin; j < end-i-1; j++){
            if( p->second[j] >  p->second[j+1]){
                t =  p->second[j];
                p->second[j] =  p->second[j+1];
                p->second[j+1] = t;
            }
        }
    }

    // int x;
    // for(x=begin; x<end; x++){
    //     sorted_list[x] = list[x];
    // }
    printf("\n");
    pthread_exit(0);
}

void *merger(void *params){
    //merge two sorted sublists
    parameters *p = params;
 
    int i = 0, j = 0, k = 0; 

    int f1 = SIZE / 2;
    int f2 = SIZE - f1;

    //Traverse both array
    while(i < f1 && j < f2){
        //check both arrays, if first element of first array is smaller than first element of second array
        //store the first element into third array then increment first array
        //otherwise do the same with second array
        if(p->first[i] < p->second[j]){
            sorted_list[k++] = p->first[i++];
        }
        else{
            sorted_list[k++] = p->second[j++];
        }
    }
    while(i < f1){//store remaining elements of first array
        sorted_list[k++] = p->first[i++];
    }
    while(j < f2){//store remaining elements of second array
        sorted_list[k++] = p->second[j++];
    }

    // int i,j,t;
    // for(i = begin; i < end; i++){
    //     for(j = begin; j < end - i; j++){
    //         if(sorted_list[j] > sorted_list[j+1]){
    //             t = sorted_list[j];
    //             sorted_list[j] = sorted_list[j+1];
    //             sorted_list[j+1] = t;
    //         }
    //     }
    // }

    // int d;
    // for(d=0;d<SIZE;d++){
    //     printf("The final array is: %d\n", sorted_list[d]);
    // }
    pthread_exit(0);
}

int main(int arc, const char* argv[]){
    //create two threads
    //create a thread to run the merger

    int i;
    pthread_t threads1;//3 threads
    pthread_t threads2;
    pthread_t threads3;
    parameters data;

    int bonk = SIZE / 2; // 5
    int secondBonk = SIZE - bonk; //10 - 5

    //create empty arrays for both halves of the list array
    data.first = malloc(sizeof(int)*(bonk));
    data.second = malloc(sizeof(int)*(secondBonk));

    //fills in first half of array
    for(i = 0; i < bonk; i++){
        data.first[i] = list[i];
    }
    //fills in second half of array
    for(int j = 0; j < secondBonk; j++){
        data.second[j] = list[j + secondBonk];
    }

    //create first thread
    pthread_create(&(threads1), NULL, &sorter, (void*)&data);
    //create second thread
    pthread_create(&(threads2), NULL, &sorter2, (void*)&data);

    pthread_join(threads1, NULL);
    pthread_join(threads2, NULL);
    
    //create third thread
    pthread_create(&(threads3), NULL, &merger, (void*)&data);


    //waits for merge thread
    pthread_join(threads3, NULL);

    for(int one = 0; one < bonk; one++){//outputs first sorted array
        printf(" %d ", data.first[one]);
    }
    printf("\n");
    for(int two = 0; two < secondBonk; two++){//outputs second sorted array
        printf(" %d ", data.second[two]);
    }
    printf("\n");
    for(int three = 0; three < SIZE; three++){//outputs third sorted array
        printf(" %d ", sorted_list[three]);
    }
    printf("\n");

    return 0;
}