Project 3 README 
--------------------

This program will introduce a multithreaded sorting application.

To start this:

1) Install and setup Virtual Box thats running a Linux distro (Ubuntu is suggested) for this project.

2) Make sure to locate the lab3.c file when you download it, and remember the pathfile so you can "cd" into it on the Ubuntu terminal.

3) Once you're in the project folder, you can create an executable by running this command on the terminal, "gcc -pthread -o lab3 lab3.c". 
This executable will appear as lab3, which is the executable name.

4) After creating the executable, you can run the program with "./lab3".

5) To install the makefile, use the command "sudo apt-get install build-essential"

6) Then to use the makefile, type "make lab3". 